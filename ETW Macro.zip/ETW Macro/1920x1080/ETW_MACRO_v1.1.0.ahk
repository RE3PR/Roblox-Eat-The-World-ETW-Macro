﻿; Copyright (C) 2026 Your Name
; Licensed under GPL-3.0-or-later
; See LICENSE file for full license details


#Requires AutoHotkey v2.0
#SingleInstance Force
SetWorkingDir A_ScriptDir
CoordMode "Pixel", "Screen"
CoordMode "Mouse", "Screen"
SendMode "Event"

#Include Gdip_All.ahk

if !pToken := Gdip_Startup() {
    MsgBox "GDI+ failed to start"
    ExitApp()
}
global lastOCR := ""
global stableStart := 0
global isPaused := false
global lastPauseTime := 0

flagFile  := A_Temp "\clicking.flag"
pauseFile := A_Temp "\pause.flag"
speedFile := A_Temp "\speed.txt"
global lastOCR := ""
global stableStart := 0
global isPaused := false
global privateLink := ""
global ExitKey := "o"
global PauseKey := "p"
global Language := "English"
global DeviceType := "Windows"
global UpgradeSystem := "Size"
global RatioValue :=  5.5
global Browser := "Google Chrome"
global map_Studville := 0
global map_MiddleRobloxia := 0
global map_BlockTown := 1
global map_MegaGrid := 1
global map_MegaBaseplate := 1
global map_TownOfRobloxia := 1

global isRunning := false
global selectedMaps := Map()
global tesseractPath := "C:\Program Files\Tesseract-OCR\tesseract.exe"
global lastPauseToggle := 0

global lastOCR := ""
global stableStart := 0
global isPaused := false

global originalWidth := ""
global originalHeight := ""
global originalDPI := ""
global logFile := ""

settingsDir := A_AppData "\ETWMacro"
if !DirExist(settingsDir)
    DirCreate(settingsDir)

global linkFile := settingsDir "\link.txt"

global linkFile := settingsDir "\link.txt"
; Create link.txt if it doesn't exist
if !FileExist(linkFile) {
    defaultContent := ""
    defaultContent .= "link=`n"
    defaultContent .= "exit=o`n"
    defaultContent .= "pause=p`n"
    defaultContent .= "language=English`n"
    defaultContent .= "device=Windows`n"
    defaultContent .= "browser=Google Chrome`n"
    defaultContent .= "upgrade=Size`n"
    defaultContent .= "ratio=5.5`n"

    defaultContent .= "map_Studville=0`n"
    defaultContent .= "map_MiddleRobloxia=0`n"
    defaultContent .= "map_BlockTown=1`n"
    defaultContent .= "map_MegaGrid=1`n"
    defaultContent .= "map_MegaBaseplate=1`n"
    defaultContent .= "map_TownOfRobloxia=1`n"

    FileAppend(defaultContent, linkFile)
}


CreateLogFile() {
    global logFile

    logsDir := A_ScriptDir "\Logs"

    ; Create Logs folder if missing
    if !DirExist(logsDir)
        DirCreate(logsDir)

    ; File name based on current time
    fileTime := FormatTime(, "yyyy-MM-dd_HH-mm-ss")

    ; Example:
    ; Logs\2026-05-08_17-30-15.txt
    logFile := logsDir "\" fileTime ".txt"
}

global lastLogText := ""

WriteLog(text) {
    global logFile, lastLogText

    if (logFile = "")
        CreateLogFile()

    ; block duplicate consecutive logs
    if (text = lastLogText)
        return

    lastLogText := text

    timestamp := FormatTime(, "HH:mm:ss")
    FileAppend("[" timestamp "] " text "`n", logFile)
}

versionFile := A_ScriptDir "\version.txt"
versionURL := "https://raw.githubusercontent.com/RE3PR/Roblox-Eat-The-World-ETW-Macro/refs/heads/main/version.txt"

GetLocalVersion(filePath) {
    try {
        if FileExist(filePath)
            return Trim(FileRead(filePath))
    }
    return ""
}

GetOnlineVersion(url) {
    try {
        whr := ComObject("WinHttp.WinHttpRequest.5.1")
        whr.Open("GET", url, false)
        whr.Send()
        return Trim(whr.ResponseText)
    }
    return ""
}

CheckVersion() {
    global versionFile, versionURL

    githubLink := "https://github.com/RE3PR/Roblox-Eat-The-World-ETW-Macro"

    if !FileExist(versionFile) {
        ShowUpdateGUI("version.txt not found", githubLink)
        return
    }

    localVer := CleanVersion(GetLocalVersion(versionFile))
    onlineVer := CleanVersion(GetOnlineVersion(versionURL))

    if (localVer = "" || onlineVer = "")
        return

    if (localVer != onlineVer) {
        ShowUpdateGUI(
            "Your macro is OUTDATED.`n`nInstalled: " localVer "`nLatest: " onlineVer,
            githubLink
        )
    }
}
ShowUpdateGUI(message, link) {
    g := Gui("+AlwaysOnTop", "Update Required")
    g.SetFont("s10")

    g.Add("Text", "w320", message)

    linkText := g.Add("Text", "w320 cBlue", "Click here to update on GitHub")
    linkText.OnEvent("Click", (*) => OpenLinkWithBrowser(link))

    done := false

    g.Add("Button", "y+15 w100", "OK").OnEvent("Click", (*) => (
        done := true,
        g.Destroy()
    ))

    g.Show()

    while (!done)
        Sleep 50
}

OpenLinkWithBrowser(link) {
    try {
        Run(link)  
    } catch {
        MsgBox "Failed to open link."
    }
}
CleanVersion(str) {
    str := Trim(str)
    str := StrReplace(str, "`r")
    str := StrReplace(str, "`n")
    str := StrReplace(str, " ")
    return str
}


CheckVersion()

IsValidLink(link) {
    return InStr(link, "https://www.roblox.com/share?code=")
}

SafeInt(str) {
    str := Trim(str)         
    if (str = "")
        return 0
    try
        return Integer(str)
    catch
        return 0               
}


map_Studville      := Integer(map_Studville      || 0)
map_MiddleRobloxia := Integer(map_MiddleRobloxia || 0)
map_BlockTown      := Integer(map_BlockTown      || 0)
map_MegaGrid       := Integer(map_MegaGrid       || 0)
map_MegaBaseplate  := Integer(map_MegaBaseplate  || 0)
map_TownOfRobloxia := Integer(map_TownOfRobloxia || 0)


if (ExitKey = "")    ExitKey := "o"
if (PauseKey = "")   PauseKey := "p"
if (Language = "")   Language := "English"
if (DeviceType = "") DeviceType := "Windows"


if FileExist(linkFile) {
    data := FileRead(linkFile)

for line in StrSplit(data, "`n", "`r") {
    line := Trim(line)
    if (line = "")
        continue

    pos := InStr(line, "=")
    if (!pos)
        continue

    key := Trim(SubStr(line, 1, pos - 1))
    value := Trim(SubStr(line, pos + 1))

    switch key {
        case "link": privateLink := value
        case "exit": ExitKey := value
        case "pause": PauseKey := value
        case "language": Language := value
        case "device": DeviceType := value
        case "browser": Browser := value
        case "upgrade": UpgradeSystem := value
        case "ratio": RatioValue := value + 0

        case "map_Studville": map_Studville := SafeInt(value)
        case "map_MiddleRobloxia": map_MiddleRobloxia := SafeInt(value)
        case "map_BlockTown": map_BlockTown := SafeInt(value)
        case "map_MegaGrid": map_MegaGrid := SafeInt(value)
        case "map_MegaBaseplate": map_MegaBaseplate := SafeInt(value)
        case "map_TownOfRobloxia": map_TownOfRobloxia := SafeInt(value)
    }
}
}
localVer := GetLocalVersion(versionFile)
if (localVer = "")
    localVer := "Unknown"

MyGui := Gui("-MinimizeBox", "Eat The World Macro v" localVer)

MyGui.Add("Tab3", "x10 y10 w380 h280 vMainTabs", ["General", "Keybinds", "Map Selection"])

MyGui["MainTabs"].UseTab(1)

MyGui.Add("Text", "x30 y50", "Selected Resolution:")
MyGui.Add("DropDownList", "x180 y45 w150 vResolution Choose1", ["1920x1080 (16:9)"])

MyGui.Add("Text", "x30 y80", "Device Type:")
ddlDevice := MyGui.Add("DropDownList", "x180 y75 w150 vDeviceType", ["Windows", "Laptop"])

if (DeviceType = "Laptop")
    ddlDevice.Choose(2)
else
    ddlDevice.Choose(1)

ddlDevice.OnEvent("Change", SaveDevice)

MyGui.Add("Text", "x30 y110 vStatusText", "Status: Checking...")
btnEdit := MyGui.Add("Button", "x180 y108 w150", "Edit link")
btnEdit.OnEvent("Click", OpenEditGui)

MyGui.Add("Text", "x30 y140", "Browser:")

ddlBrowser := MyGui.Add("DropDownList", "x180 y135 w150 vBrowser",
    ["Google Chrome","Microsoft Edge","Mozilla Firefox","Opera","Opera GX","Brave","Vivaldi","Safari","360 Extreme Browser"])

browserList := ["Google Chrome","Microsoft Edge","Mozilla Firefox","Opera","Opera GX","Brave","Vivaldi","Safari"]

browserIndex := 1
for i, val in browserList {
    if (val = Browser) {
        browserIndex := i
        break
    }
}
ddlBrowser.Choose(browserIndex)

ddlBrowser.OnEvent("Change", SaveBrowser)

MyGui.Add("Text", "x30 y170", "Upgrade System:")

ddlUpgrade := MyGui.Add("DropDownList", "x180 y165 w150 vUpgradeSystem",
    ["Size","WalkSpeed","Multiplier","EatSpeed","Ratio","Coins"])


upgradeIndex := 1
for i, val in ["Size","WalkSpeed","Multiplier","EatSpeed","Ratio","Coins"] {
    if (val = UpgradeSystem) {
        upgradeIndex := i
        break
    }
}
ddlUpgrade.Choose(upgradeIndex)

ddlUpgrade.OnEvent("Change", UpgradeChanged)

MyGui.Add("Text", "x30 y205 vRatioLabel Hidden", "Ratio (4.0 - 6.0):")
MyGui.Add("Edit", "x180 y200 w60 vRatioValue Hidden", RatioValue)

btnMinus := MyGui.Add("Button", "x250 y200 w30 h23 vRatioMinus Hidden", "-")
btnPlus  := MyGui.Add("Button", "x285 y200 w30 h23 vRatioPlus Hidden", "+")

btnMinus.OnEvent("Click", RatioDown)
btnPlus.OnEvent("Click", RatioUp)

MyGui["MainTabs"].UseTab(2)

MyGui.Add("Text", "x30 y40 w200", "Click a box then press a key")
MyGui.Add("Text", "x30 y80 w80", "Exit:")

hkExit := MyGui.Add("Hotkey", "x120 y77 w100 vExitKey", ExitKey)
hkExit.OnEvent("Change", SaveKeys)

MyGui.Add("Text", "x30 y120 w80", "Pause:")

hkPause := MyGui.Add("Hotkey", "x120 y117 w100 vPauseKey", PauseKey)
hkPause.OnEvent("Change", SaveKeys)

MyGui["MainTabs"].UseTab(3)

MyGui.Add("Text", "x30 y45 w250 h20", "Choose the maps you want to farm:")
MyGui.Add("GroupBox", "x20 y70 w350 h190")

MyGui.Add("Text", "x40 y82 w200 h20", "Map Name")

cbStudville := MyGui.Add("CheckBox", "x40 y100 w200 h20 vmap_Studville", "Studville (worst map)")
cbMiddle := MyGui.Add("CheckBox", "x40 y125 w250 h20 vmap_MiddleRobloxia", "Middle Robloxia")
cbBlock := MyGui.Add("CheckBox", "x40 y150 w220 h20 vmap_BlockTown", "Block Town")
cbMegaGrid := MyGui.Add("CheckBox", "x40 y175 w150 h20 vmap_MegaGrid", "Mega Grid")
cbMegaBase := MyGui.Add("CheckBox", "x40 y200 w150 h20 vmap_MegaBaseplate", "Mega Baseplate")
cbTown := MyGui.Add("CheckBox", "x40 y225 w180 h20 vmap_TownOfRobloxia", "Town of Robloxia")

cbStudville.OnEvent("Click", SaveMaps)
cbMiddle.OnEvent("Click", SaveMaps)
cbBlock.OnEvent("Click", SaveMaps)
cbMegaGrid.OnEvent("Click", SaveMaps)
cbMegaBase.OnEvent("Click", SaveMaps)
cbTown.OnEvent("Click", SaveMaps)

MyGui["map_Studville"].Value := map_Studville
MyGui["map_MiddleRobloxia"].Value := map_MiddleRobloxia
MyGui["map_BlockTown"].Value := map_BlockTown
MyGui["map_MegaGrid"].Value := map_MegaGrid
MyGui["map_MegaBaseplate"].Value := map_MegaBaseplate
MyGui["map_TownOfRobloxia"].Value := map_TownOfRobloxia

MyGui["MainTabs"].UseTab()

MyGui.SetFont("cBlack s9")

txtCredit := MyGui.Add("Text", "x20 y300 w200 h20", "Made by Reaper")
txtLang   := MyGui.Add("Text", "x250 y300 w60 h20", "Language:")

ddlLanguage := MyGui.Add("DropDownList", "x310 y298 w100 vLanguage", ["English"])

if (Language = "English")
    ddlLanguage.Choose(1)

ddlLanguage.OnEvent("Change", SaveLang)

btnExit := MyGui.Add("Button", "x20 y330 w80 h25", "Exit")
btnStart := MyGui.Add("Button", "x310 y330 w80 h25", "Start")

btnExit.OnEvent("Click", ExitScript)
btnStart.OnEvent("Click", StartScript)

MyGui.Show("w420 h370")

if (UpgradeSystem = "Ratio")
    UpgradeChanged()
    
if (DeviceType = "Laptop")
    MyGui["DeviceType"].Choose(2)
else
    MyGui["DeviceType"].Choose(1)

MyGui["DeviceType"].Redraw()

SaveAll()
UpdateStatus()

SaveBrowser(*) {
    global Browser, MyGui

    Browser := MyGui["Browser"].Text

    if (Browser = "")
        Browser := "Google Chrome"

    SaveAll()
}

SaveMaps(*) {
    global map_Studville, map_MiddleRobloxia, map_BlockTown
    global map_MegaGrid, map_MegaBaseplate, map_TownOfRobloxia, MyGui

    map_Studville      := MyGui["map_Studville"].Value
    map_MiddleRobloxia := MyGui["map_MiddleRobloxia"].Value
    map_BlockTown      := MyGui["map_BlockTown"].Value
    map_MegaGrid       := MyGui["map_MegaGrid"].Value
    map_MegaBaseplate  := MyGui["map_MegaBaseplate"].Value
    map_TownOfRobloxia := MyGui["map_TownOfRobloxia"].Value

    SaveAll()
}

SaveKeys(*) {
    global ExitKey, PauseKey
    ExitKey := MyGui["ExitKey"].Value
    PauseKey := MyGui["PauseKey"].Value
    
    if (ExitKey = "")    ExitKey := "o"
    if (PauseKey = "")   PauseKey := "p"
    
    SaveAll()
}

SaveLang(*) {
    global Language
    Language := MyGui["Language"].Text
    if (Language = "")
        Language := "English"
    SaveAll()
}

SaveDevice(*) {
    global DeviceType, MyGui

    idx := MyGui["DeviceType"].Value
    DeviceType := (idx = 2) ? "Laptop" : "Windows"

    SaveAll()   
}

OpenEditGui(*) {
    global privateLink, MyGui
    
    prevText := (privateLink = "") ? "Previous link: None" : "Previous link: " . privateLink
    
    editGui := Gui("-MinimizeBox +Owner" MyGui.Hwnd, "Edit Private Link")
    
    editGui.Add("Text", "x20 y20 w350 vPrevLinkText", prevText)
    editGui.Add("Text", "x20 y60", "Private server link:")
    editGui.Add("Edit", "x20 y80 w350 vNewLink", privateLink)

    editGui.Add("Button", "x60 y130 w100", "Cancel").OnEvent("Click", (*) => editGui.Destroy())
    editGui.Add("Button", "x200 y130 w100", "Update").OnEvent("Click", (*) => SaveLink(editGui))
    
    editGui.Show("w400 h180")
}

CancelEdit(guiObj) {
    guiObj.Destroy()
}

SaveLink(editGui) {
    global privateLink
    
    newLink := Trim(editGui["NewLink"].Value)
    
    if (!IsValidLink(newLink)) {
        MsgBox("Please enter a valid Roblox private server link.", "Invalid Link", "Iconx")
        editGui["NewLink"].Value := privateLink   
        return
    }
    
    privateLink := newLink

    SaveAll()
    editGui.Destroy()
    UpdateStatus()
    TrayTip("Link saved successfully!", "Eat The World Bot", 0x1)
}

SaveAll() {
    global UpgradeSystem, RatioValue
    global privateLink, ExitKey, PauseKey, Language, DeviceType
    global map_Studville, map_MiddleRobloxia, map_BlockTown, map_MegaGrid, map_MegaBaseplate, map_TownOfRobloxia
    global coinCollection, coin_MaxLevel, coin_Multi, coin_Walk, coin_Eat
    global MyGui, linkFile


    if IsSet(MyGui) {

        UpgradeSystem := MyGui["UpgradeSystem"].Text
        RatioValue := MyGui["RatioValue"].Value + 0

        ExitKey := MyGui["ExitKey"].Value
        PauseKey := MyGui["PauseKey"].Value

        map_Studville      := MyGui["map_Studville"].Value
        map_MiddleRobloxia := MyGui["map_MiddleRobloxia"].Value
        map_BlockTown      := MyGui["map_BlockTown"].Value
        map_MegaGrid       := MyGui["map_MegaGrid"].Value
        map_MegaBaseplate  := MyGui["map_MegaBaseplate"].Value
        map_TownOfRobloxia := MyGui["map_TownOfRobloxia"].Value

    }

    FileDelete(linkFile)

    safeLink := IsValidLink(privateLink) ? privateLink : ""

content := ""

content .= "link=" safeLink "`n"
content .= "exit=" ExitKey "`n"
content .= "pause=" PauseKey "`n"
content .= "language=" Language "`n"
content .= "device=" DeviceType "`n"
content .= "browser=" Browser "`n"
content .= "upgrade=" UpgradeSystem "`n"
content .= "ratio=" RatioValue "`n"

content .= "map_Studville=" map_Studville "`n"
content .= "map_MiddleRobloxia=" map_MiddleRobloxia "`n"
content .= "map_BlockTown=" map_BlockTown "`n"
content .= "map_MegaGrid=" map_MegaGrid "`n"
content .= "map_MegaBaseplate=" map_MegaBaseplate "`n"
content .= "map_TownOfRobloxia=" map_TownOfRobloxia "`n"
    

    FileAppend(content, linkFile)
}

UpdateStatus() {
    valid := IsValidLink(privateLink)
    
    if (valid) {
        MyGui["StatusText"].Text := "Status: Good link provided"
        MyGui["StatusText"].SetFont("cGreen Bold")
    } else {
        MyGui["StatusText"].Text := "Status: No valid link"
        MyGui["StatusText"].SetFont("cRed Bold")
    }
}

StartScript(*) {
    global privateLink, ExitKey, PauseKey, coinCollection
    global map_Studville, map_MiddleRobloxia, map_BlockTown, map_MegaGrid, map_MegaBaseplate, map_TownOfRobloxia
    global originalWidth, originalHeight, originalDPI
    Hotkey(ExitKey, HandleExit, "On")
    Hotkey(PauseKey, HandlePause, "On")

    if (!IsValidLink(privateLink)) {
        MsgBox("You must set a valid private server link before starting.", "Error", "Iconx")
        return
    }

    if (ExitKey = PauseKey) {
        MsgBox("Exit key and Pause key cannot be the same.", "Keybind Error", "Iconx")
        MyGui.Show()
        MyGui["MainTabs"].Choose(2)
        return
    }

    if (!(map_Studville || map_MiddleRobloxia || map_BlockTown || map_MegaGrid || map_MegaBaseplate || map_TownOfRobloxia)) {
        MsgBox("You must select at least 1 map before starting.", "Map Error", "Iconx")
        MyGui.Show()
        MyGui["MainTabs"].Choose(3)
        return
    }


    res := GetCurrentResolution()
    parts := StrSplit(res, "|")
    originalWidth := parts[1]
    originalHeight := parts[2]
    originalDPI := GetScaling()
    

    SetResolution(1920, 1080)
	Sleep 2000 
    SetScaling(96)  
    
    Hotkey(ExitKey, HandleExit, "On")
 
    MyGui.Hide()
    WriteLog("Running " MyGui.Title)
    isRunning := true

if !WinExist("ahk_exe RobloxPlayerBeta.exe") { ;Checking if roblox is running
    Sleep 430
    Rejoin()
} else {
    WinActivate("ahk_exe RobloxPlayerBeta.exe")  ;If Roblox is running go to StartLogic
    WriteLog("Roblox is running")
    Sleep 2000
    StartLogic()
}
    SetTimer(MainLoop, 10000) ;Timer to check if Roblox is running
	SetTimer(CheckCrash, 10000) ;Timer to check if user lost connection
}

ExitScript(*) => ExitApp()

MyGui.OnEvent("Close", (*) => ExitApp())

MainLoop(*) {
    if !WinExist("ahk_exe RobloxPlayerBeta.exe") {
        Rejoin()
    } else {
        WinActivate("ahk_exe RobloxPlayerBeta.exe")
    }
    Sleep 2000
}
StartLogic() {

    Loop {
	WaitIfPaused()
        style := WinGetStyle("ahk_exe RobloxPlayerBeta.exe")

        if (style & 0xC00000) {
            Send "{F11}"
            Sleep 1000
        } else {
            break
        }
    }

start := A_TickCount
rgbDetected := false
WriteLog("Roblox is fullscreen")

Loop {
    current := PixelGetColor(292, 1003, "RGB")

    if (ColorMatch(current, 0x171B1C, 10)) {
        rgbDetected := true
        break
    }

    if (A_TickCount - start > 4000) {
        break
    }

    Sleep 50
}

color1 := PixelGetColor(29, 1039, "RGB")

if (!ColorMatch(color1, 0x000000, 10)) {  ;Checking if you are in ETW
    WriteLog("Not in Eat The World, going to rejoin")
    Rejoin()
    return
}

WriteLog("In Eat The World")
color2 := PixelGetColor(1619, 208, "RGB")
color3 := PixelGetColor(65, 589, "RGB")
color4 := PixelGetColor(1535, 220, "RGB")

if (ColorMatch(color2, 0xD10000, 12)) {  ;Checking any blocking UI's
    WriteLog("Shop/Nametag Menu detected, closing it")
    Click 1619, 220
    Sleep 400
}

if (!ColorMatch(color3, 0xBDBDBD, 10) && ColorMatch(color4, 0xD10000, 12)) {

    extraColor := PixelGetColor(637, 294, "RGB")

    if (ColorMatch(extraColor, 0xE70000, 12)) {
        WriteLog("Collecting WheelSpin")
        Click 630, 900
        Sleep 500
    }

    Click 1535, 230
}

if (CheckColor(65, 589, 0xBDBDBD, 10)) {
    WriteLog("Crates Detected")
    if (!ColorMatch(color4, 0xD10000, 12)) {
        WriteLog("Opening Crates Menu") 
        Click 37, 584
        Sleep 300
    }

   detected := []

    CheckAndStore(checkX, checkY, clickX, clickY) {
        col := PixelGetColor(checkX, checkY, "RGB")

        if (ColorMatch(col, 0xFFFFFF, 10)) {
            detected.Push([clickX, clickY])
        }
    }

    CheckAndStore(1172, 439, 1080, 431)
    CheckAndStore(1369, 438, 1275, 431)
    CheckAndStore(1567, 439, 1480, 431)

    CheckAndStore(1172, 621, 1080, 615)
    CheckAndStore(1369, 622, 1275, 615)
    CheckAndStore(1567, 618, 1480, 615)

    CheckAndStore(1172, 804, 1080, 800)
    CheckAndStore(1369, 802, 1275, 800)
    CheckAndStore(1567, 804, 1480, 800)

    lastIndex := detected.Length

    if (lastIndex >= 1) {
        Loop lastIndex {
            WaitIfPaused()
            pos := detected[A_Index]

            Click pos[1], pos[2]
            WriteLog("Collecting Crates")

            if (A_Index < lastIndex)
                Sleep 3000
        }
    }

    extraColor := PixelGetColor(634, 282, "RGB")

    if (ColorMatch(extraColor, 0xE70000, 12)) {
        Sleep 3000
        WriteLog("Collecting WheelSpin")
        Click 639, 911
    }
    WriteLog("Closing Crates Menu")
    Click 1535, 230

} else {

    color4 := PixelGetColor(1537, 221, "RGB")

    if (ColorMatch(color4, 0xD10000, 12)) {
        color5 := PixelGetColor(634, 282, "RGB")

        if (ColorMatch(color5, 0xE70000, 12)) {
            WriteLog("Collecting WheelSpin")
            Click 639, 911
            Sleep 500
            WriteLog("Closing Crates Menu")
            Click 1535, 230
        }
    }
}

MegaMaps()
}

MegaMaps() {
Loop {
    checkStart := PixelGetColor(247, 1029, "RGB")

    if !ColorMatch(checkStart, 0x3C8F26, 15)
        break

    Loop {
        checkStop := PixelGetColor(244, 1036, "RGB")

        if ColorMatch(checkStop, 0x1A1D1E, 15)
            break
        
        WriteLog("Selling")
        Click(215, 1000)
        Sleep(50)
    }

    break  
}

Loop {
    current := PixelGetColor(261, 1033, "RGB")
    if (ColorMatch(current, 0x1B1E1F, 10))
        break
    Sleep 50
}

checkBlack := PixelGetColor(40, 1039, "RGB")
if (!ColorMatch(checkBlack, 0x000000, 15)) {
    WriteLog("Not in private, rejoining")
    Rejoin()
    return
}

    whiteCheck := PixelGetColor(66, 619, "RGB")

    if (!ColorMatch(whiteCheck, 0xFFFFFF, 10)) {

        Loop {
            WaitIfPaused()
            checkColor := PixelGetColor(815, 652, "RGB")

            if (ColorMatch(checkColor, 0x181A1B, 10))
                break

            WriteLog("Opening Mega Maps Menu")
            Click 64, 650
            Sleep 200

            checkColor := PixelGetColor(815, 652, "RGB")

            if (ColorMatch(checkColor, 0x181A1B, 10))
                break

            Loop {
                WaitIfPaused()
                WriteLog("Attempting to open Mega Maps Menu")
                Click 64, 650
                Sleep 1000

                checkColor := PixelGetColor(815, 652, "RGB")

                if (ColorMatch(checkColor, 0x181A1B, 10))
                    break 2
            }
        }

        Sleep 250

Loop {
    WaitIfPaused()

    whiteCheck := PixelGetColor(66, 619, "RGB")
    if (ColorMatch(whiteCheck, 0xFFFFFF, 10))
        break

    Loop 5 {
        WaitIfPaused()

        whiteCheck := PixelGetColor(66, 619, "RGB")
        if (ColorMatch(whiteCheck, 0xFFFFFF, 10))
            break 2  
        WriteLog("Joining Mega Maps")
        Click 961, 732
        Sleep 1000
    }

    Sleep 3000
}
    }

startTime := A_TickCount

Loop {
    current := PixelGetColor(254, 1024, "RGB")

    elapsed := (A_TickCount - startTime) // 1000

    if (ColorMatch(current, 0x1B1E1F, 10)) {
        break
    }

    if (A_TickCount - startTime >= 10000) {
        WriteLog("Rejoining roblox due to bug")
        GoEndLogic()
        return
    }

    Sleep 50
}


checkBlack2 := PixelGetColor(41, 1039, "RGB")
if (!ColorMatch(checkBlack2, 0x000000, 15)) {
    WriteLog("Not in private, rejoining")
    Rejoin()
    return
}
    CheckSelectedMap()
}

CheckSelectedMap() {
if (!WaitForMaps()) {
    return
}

settings := Map()

if FileExist(linkFile) {
    content := FileRead(linkFile)

    for line in StrSplit(content, "`n", "`r") {

        line := Trim(line)
        if (line = "" || !InStr(line, "="))
            continue

        parts := StrSplit(line, "=", , 2) 

        key := Trim(parts[1])
        val := Trim(parts[2])

        settings[key] := val
    }
} else {
    MsgBox("link.txt not found")
    return
}

    maps := Map()

    maps["Mega Baseplate"] := [
        {x:889, y:16, color:0xE1E1E1},
        {x:1031, y:16,  color:0xFFFFFF}
    ]

    maps["Mega Grid"] := [
        {x:974, y:20,  color:0x5E5E5E},
        {x:1008, y:14, color:0x5C5C5C}
    ] 
	
    maps["Town of Robloxia"] := [
        {x:1043, y:12, color:0x7C7C7C},
        {x:912, y:18, color:0xFDFDFD}
    ]

    maps["Middle Robloxia"] := [
        {x:932, y:14, color:0xFFFFFF},
        {x:1032, y:19, color:0x000000}
    ]

    maps["Block Town"] := [
        {x:913, y:16, color:0x2F2F2F},
        {x:1002, y:20, color:0x2D2D2D}
    ]

    maps["Studville"] := [
        {x:944, y:20, color:0x7E7E7E},
        {x:1002, y:14, color:0xCFCFCF}
    ]


    nameMap := Map(
        "Mega Baseplate", "map_MegaBaseplate",
        "Mega Grid", "map_MegaGrid",
        "Town of Robloxia", "map_TownOfRobloxia",
        "Middle Robloxia", "map_MiddleRobloxia",
        "Block Town", "map_BlockTown",
        "Studville", "map_Studville"
    )

anySelected := false

for mapName, pixels in maps {

    keyName := nameMap[mapName]
    val := settings.Has(keyName) ? Trim(settings[keyName]) : "0"

    if (Integer(val) = 1) {
        anySelected := true

        matchAll := true

        for p in pixels {
            c := PixelGetColor(p.x, p.y, "RGB")

            if (!ColorMatch(c, p.color)) {
                matchAll := false
                break
            }
        }

 if (matchAll)
            WriteLog("Map detected")
        else
            WriteLog("Waiting for map")

        if (matchAll) {
         SendEvent("{Esc}")
         WriteLog("Sending Esc")
         lastSend := A_TickCount

    loop {
        col := PixelGetColor(654, 242, "RGB")

        if (ColorMatch(col, 0xFFFFFF, 15))
            break

        if (A_TickCount - lastSend >= 3000) {
            SendEvent("{Esc}")
            WriteLog("Sending Esc")
            
            lastSend := A_TickCount
        }

        Sleep(50)
    }

    Sleep(150)
    SendEvent("r")
    WriteLog("Sending R")
    lastSend := A_TickCount

    loop {
        col := PixelGetColor(1052, 357, "RGB")

        if (ColorMatch(col, 0xDEE0E7, 10))
            break

        if (A_TickCount - lastSend >= 3000) {
            SendEvent("r")
            WriteLog("Sending R")
            lastSend := A_TickCount
        }

        Sleep(50)
    }

    Sleep(250)

    Loop {
        col := PixelGetColor(63, 617, "RGB")

        if (ColorMatch(col, 0xFFFFFF, 8))
            break

        SendEvent("{Enter}")
        WriteLog("Sending Enter")
        Sleep(300)
    }

WriteLog("Avatar reset")
Sleep(6000)
MainMacro()
return
}
    }
}

if (anySelected) {
    MapSelection()
    return
}
}

ColorMatch(c1, c2, tolerance := 10) {
    r1 := (c1 >> 16) & 0xFF
    g1 := (c1 >> 8) & 0xFF
    b1 := c1 & 0xFF

    r2 := (c2 >> 16) & 0xFF
    g2 := (c2 >> 8) & 0xFF
    b2 := c2 & 0xFF

    return (Abs(r1 - r2) <= tolerance
         && Abs(g1 - g2) <= tolerance
         && Abs(b1 - b2) <= tolerance)
}

WaitForMaps(timeout := 10000) {
    start := A_TickCount

maps := [
    [{x:889, y:16,  color:0xE1E1E1}, {x:1031, y:16, color:0xFFFFFF}], ; Mega Baseplate
    [{x:974, y:20,  color:0x5E5E5E}, {x:1008, y:14, color:0x5C5C5C}], ; Mega Grid
    [{x:1043, y:12, color:0x7C7C7C}, {x:912,  y:18, color:0xFDFDFD}], ; Town of Robloxia
    [{x:932, y:14,  color:0xFFFFFF}, {x:1032, y:19, color:0x000000}], ; Middle Robloxia
    [{x:913, y:16,  color:0x2F2F2F}, {x:1002, y:20, color:0x2D2D2D}], ; Block Town
    [{x:944, y:20,  color:0x7E7E7E}, {x:1002, y:14, color:0xCFCFCF}]  ; Studville
 ]

    while (A_TickCount - start < timeout) {

        for pixels in maps {

            matchAll := true

            for p in pixels {
                c := PixelGetColor(p.x, p.y, "RGB")

                if (!ColorMatch(c, p.color)){
                    matchAll := false
                    break
                }
            }

            if (matchAll) {
                return true
            }
        }

        Sleep(200) 
    }

    return false 
}


MapSelection() {
    global selectedMaps

        if (CheckColor(1530, 223, 0xD10000, 12)) {
        StopClicking()
        Click 1533, 232
        Sleep 100  
    }

    Loop {
        WaitIfPaused()
        mapReady := PixelGetColor(817, 594, "RGB")
        if (CheckColor(817, 594, 0x181A1B, 10))
            break
        WriteLog("Opening Map Menu")
        Click 49, 1032
        Sleep 200
    }

    col1 := PixelGetColor(886,506, "RGB")
    col2 := PixelGetColor(890, 504, "RGB")

    if (CheckColor(886,506, 0x52B04D, 12) || CheckColor(890, 504, 0x397B36, 12)) {
        WriteLog("Clicking Skip Map")
        Click 958, 689
        Sleep 500
    } else {
        WriteLog("Unpausing Timer")
        Click 880, 508
        Sleep 200
        WriteLog("Clicking Skip Map")
        Click 958, 689
        Sleep 500
    }


activeMaps := []

if (map_MegaBaseplate)
    activeMaps.Push("MegaBaseplate")

if (map_MegaGrid)
    activeMaps.Push("MegaGrid")

if (map_TownOfRobloxia)
    activeMaps.Push("TownOfRobloxia")

if (map_MiddleRobloxia)
    activeMaps.Push("MiddleRobloxia")

if (map_Studville)
    activeMaps.Push("Studville")

if (map_BlockTown)
    activeMaps.Push("BlockTown")


MapData := Map()

MapData["MegaBaseplate"] := [
    {x: 1157, y: 226, color: 0x23914B, tol: 12}
]

MapData["MegaGrid"] := [
    {x: 761,  y: 227, color: 0xC47DBE, tol: 12},
    {x: 971,  y: 228, color: 0xC676BF, tol: 12},
    {x: 1159, y: 226, color: 0xC46DBE, tol: 12}
]

MapData["TownOfRobloxia"] := [
    {x: 959, y: 224, color: 0x4EA959, tol: 12},
    {x: 976, y: 228, color: 0x5C2D15, tol: 12}
]

MapData["MiddleRobloxia"] := [
    {x: 754, y: 228, color: 0xAB8D65, tol: 12}
]

MapData["Studville"] := [
    {x: 763,  y: 226, color: 0x133F30, tol: 12},
    {x: 1024, y: 223, color: 0x2D5244, tol: 12}
]

MapData["BlockTown"] := [
    {x: 772,  y: 220, color: 0xAAC14C, tol: 12},
    {x: 959,  y: 227, color: 0x386D95, tol: 12},
    {x: 1156, y: 225, color: 0x524C0D, tol: 12}
]

Sleep 1000
Loop {
    WaitIfPaused()
    found := false

    for mapName in activeMaps {
        checks := MapData[mapName]

        for check in checks {
            if (CheckColor(check.x, check.y, check.color, check.tol)) {
                WriteLog("Voting map: " mapName "  ")
                Click (check.HasProp("clickX") ? check.clickX : check.x)
                    , (check.HasProp("clickY") ? check.clickY : check.y)

                found := true
                break 2
            }
        }
    }

    if (found) {
        WaitMapLoad()
        break
    }

        if (found) {
            WaitMapLoad()
            break
        }

        c1 := PixelGetColor(942, 44, "RGB")
        c2 := PixelGetColor(954, 41, "RGB")

        if (CheckColor(942, 44, 0xFFFFFF, 10) || CheckColor(954, 41, 0xFFFFFF, 10)) {
            WriteLog("Clicking Skip Map")
            Click 958, 689
            Sleep 500

            while (true) {
                c1 := PixelGetColor(942, 44, "RGB")
                c2 := PixelGetColor(954, 41, "RGB")

                if (!CheckColor(942, 44, 0xFFFFFF, 10) && !CheckColor(954, 41, 0xFFFFFF, 10))
                    break

                Sleep 100
            }
        }

        Sleep 200
    }

    MainMacro()
}
CheckColor(x, y, targetColor, tolerance := 5) {
    col := PixelGetColor(x, y, "RGB")

    r := (col >> 16) & 0xFF
    g := (col >> 8) & 0xFF
    b := col & 0xFF

    tr := (targetColor >> 16) & 0xFF
    tg := (targetColor >> 8) & 0xFF
    tb := targetColor & 0xFF

    return (Abs(r - tr) <= tolerance
        && Abs(g - tg) <= tolerance
        && Abs(b - tb) <= tolerance)
}

CheckMapWaitOnce(x1, y1, c1, x2 := "", y2 := "", c2 := "", x3 := "", y3 := "", c3 := "", tolerance := 5) {

    if (CheckColor(x1, y1, c1, tolerance)) {
        Click x1, y1
        return true
    }

    if (x2 != "" && CheckColor(x2, y2, c2, tolerance)) {
        Click x2, y2
        return true
    }

    if (x3 != "" && CheckColor(x3, y3, c3, tolerance)) {
        Click x3, y3
        return true
    }

    return false
}

WaitMapLoad() {
    global isRunning

    isRunning := false 

    Loop {
        WaitIfPaused()
        topWhite := PixelGetColor(939, 11, "RGB")
        if (CheckColor(939, 11, 0xFFFFFF, 10))
            break
        Sleep 500
    }

         SendEvent("{Esc}")
         WriteLog("Sending Esc")
         lastSend := A_TickCount

        loop {
        col := PixelGetColor(654, 242, "RGB")

        if (ColorMatch(col, 0xFFFFFF, 15))
            break

        if (A_TickCount - lastSend >= 3000) {
            SendEvent("{Esc}")
            WriteLog("Sending Esc")
            
            lastSend := A_TickCount
        }

        Sleep(50)
    }

    Sleep(150)
    SendEvent("r")
    WriteLog("Sending R")
    lastSend := A_TickCount

    loop {
        col := PixelGetColor(1052, 357, "RGB")

        if (ColorMatch(col, 0xDEDFE6, 10))
            break

        if (A_TickCount - lastSend >= 3000) {
            SendEvent("r")
            WriteLog("Sending R")
            lastSend := A_TickCount
        }

        Sleep(50)
    }

    Sleep(250)

    Loop {
        col := PixelGetColor(63, 617, "RGB")

        if (ColorMatch(col, 0xFFFFFF, 8))
            break

        SendEvent("{Enter}")
        WriteLog("Sending Enter")
        Sleep(300)
    }

WriteLog("Avatar reset")
Sleep(6000)
MainMacro()
isRunning := true   
}


MainMacro() {
    WaitIfPaused()
    WriteLog("Starting Autoclicker & Checkers")
    StartClicking(30)
    SetTimer Sell, 100
    Sleep 400
    SetTimer CheckRGB, 1000
    Sleep 4000
    SetTimer OCRChecker, 2000
}

AutoClicker(*) {
WaitIfPaused()
    global isPaused
    if (isPaused)
        return

    Click 145, 950
}

StartClicking(delay := 30) {
    global flagFile

    flagFile := A_Temp "\clicking.flag"

    ; clean old state
    if FileExist(flagFile)
        FileDelete(flagFile)

    attempt := 0

    while true {
        attempt++
        WriteLog("Autoclicker start attempt " attempt)

        Run A_ScriptDir "\Files\Autoclicker.ahk"

        startTime := A_TickCount
        success := false

        ; wait for autoclicker to CONFIRM it started
        while (A_TickCount - startTime < 5000) {

            WaitIfPaused()

            if FileExist(flagFile) {
                success := true
                break
            }

            Sleep 50
        }

        if success {
            WriteLog("Autoclicker started successfully")
            return true
        }

        WriteLog("Autoclicker failed, retrying...")
        Sleep 1500
    }
}

StopClicking() {
    flagFile := A_Temp "\clicking.flag"

    if FileExist(flagFile)
        FileDelete flagFile
}

Sell(*) {
WaitIfPaused()
    color1 := PixelGetColor(1471, 999, "RGB")

    if (CheckColor(1673, 1030, 0x3C8C26, 12)) {

    SetTimer CheckRGB, 0
    SetTimer StartOCR, 0
    SetTimer Sell, 0
    SetTimer OCRChecker, 0
    StartClicking(150)

Loop {
    WaitIfPaused()

    if (CheckColor(1706, 1029, 0x3C8B26, 12)) {
        WriteLog("Max Size detected")
        break
    }

    Sleep 50
}
    StopClicking()
    

    Loop {
        WaitIfPaused()
        WriteLog("Selling")
        Click 207, 1007
        Sleep 200

        if (CheckColor(276, 1031, 0x1C1F20, 10)) {
            WriteLog("Going to vote map")
            MapSelection()
            break
        }
    }
}
}

CheckRGB(*) {
    if (CheckColor(65, 587, 0xBDBDBD, 10)) { 
        WriteLog("Reward (Crate) Ready")
        SetTimer(CheckRGB, 0)
        SetTimer(StartOCR, -1)
    }
}

StartOCR(*) {
prevText := ""
stableCount := 0

Loop {
    WaitIfPaused()
    text := GetOCR(668, 996, 1249, 1064)

    stableCount := (text = prevText) ? stableCount + 1 : 0
    prevText := text

    if (stableCount >= 2)
        break

    Sleep 170
}
prevText := GetOCR(668, 996, 1249, 1064)

Loop {
    WaitIfPaused()
    text := GetOCR(668, 996, 1249, 1064)

    if (text != prevText)
        break

    Sleep 15
}

prevText := text
stableCount := 0

    StopClicking()
	SetTimer OCRChecker, 0
	Sleep 100
    WriteLog("Opening Crates Menu")
    Click 37, 584
    Sleep 350

 detected := []

    CheckAndStore(checkX, checkY, clickX, clickY) {
        col := PixelGetColor(checkX, checkY, "RGB")

        if (ColorMatch(col, 0xFFFFFF, 10)) {
            detected.Push([clickX, clickY])
        }
    }

    CheckAndStore(1172, 439, 1080, 431)
    CheckAndStore(1369, 438, 1275, 431)
    CheckAndStore(1567, 439, 1480, 431)

    CheckAndStore(1172, 621, 1080, 615)
    CheckAndStore(1369, 622, 1275, 615)
    CheckAndStore(1567, 618, 1480, 615)

    CheckAndStore(1172, 804, 1080, 800)
    CheckAndStore(1369, 802, 1275, 800)
    CheckAndStore(1567, 804, 1480, 800)

    lastIndex := detected.Length

for i, pos in detected {
    Click pos[1], pos[2]
    WriteLog("Collecting Crates")

    if (CheckColor(1477, 741, 0x341A42, 10)) {
        WriteLog("Last crate detected, going to Upgrade")
        Upgrades()
        return
    }

    if (pos[1] == 1480 && pos[2] == 800) {
        WriteLog("Last crate detected, going to Upgrade")
        Upgrades()
        return
    }

    if (lastIndex > 1 && i < lastIndex)
        Sleep 2000
}

if (CheckColor(639, 291, 0xE70000, 10)) {
    Sleep 3000
    WriteLog("Collecting WheelSpin")
    Click 642, 905
} else {
    if (CheckColor(1535, 221, 0xD10000, 10)
        && CheckColor(639, 291, 0xE70000, 10)) {
        WriteLog("Collecting WheelSpin")
        Click 642, 905
        Sleep 500
        Click 1538, 230
    }
}
WriteLog("Closing Crates Menu")
Click 1538, 230
MainMacro()

}

CheckAndStore(&arr, checkX, checkY, clickX, clickY) {
    if (PixelGetColor(checkX, checkY, "RGB") = 0xFFFFFF)
        arr.Push([clickX, clickY])
}

GetOCR(x1, y1, x2, y2)
{
    global tesseractPath

    w := x2 - x1
    h := y2 - y1

    tempImage := A_Temp "\ocr_" A_TickCount ".png"
    tempOutput := A_Temp "\ocr_" A_TickCount

    pBitmap := Gdip_BitmapFromScreen(x1 "|" y1 "|" w "|" h)

    width := Gdip_GetImageWidth(pBitmap)
    height := Gdip_GetImageHeight(pBitmap)

    Loop height {
	WaitIfPaused()
        y := A_Index - 1
        Loop width {
		WaitIfPaused()
            x := A_Index - 1

            color := Gdip_GetPixel(pBitmap, x, y)

            r := (color >> 16) & 0xFF
            g := (color >> 8) & 0xFF
            b := color & 0xFF

            if (r > 200 && g > 200 && b > 200) {
                Gdip_SetPixel(pBitmap, x, y, 0xFFFFFFFF)
            } else {     
                Gdip_SetPixel(pBitmap, x, y, 0xFF000000)
            }
        }
    }

    Gdip_SaveBitmapToFile(pBitmap, tempImage)
    Gdip_DisposeImage(pBitmap)

    RunWait '"' tesseractPath '" "' tempImage '" "' tempOutput '" --oem 3 --psm 7 -c tessedit_char_whitelist=0123456789', , "Hide"

    text := ""
    if FileExist(tempOutput ".txt") {
        text := Trim(FileRead(tempOutput ".txt"))
    }

    FileDelete tempImage
    FileDelete tempOutput ".txt"

    return text
}


PauseClicking() {
    global isPaused, pauseFile

    if (isPaused)
        return

    isPaused := true

    FileAppend "", pauseFile
    WriteLog("Stuck detected, stopping autoclicking")
    SetTimer ResumeClicking, -4000
}

ResumeClicking(*) {
    global isPaused, pauseFile

    isPaused := false

    FileDelete pauseFile
    WriteLog("Resuming Autoclicking")
    Sleep 200
    ToolTip
}

OCRChecker(*) {
    global lastOCR, stableStart, isPaused, lastPauseTime

    current := GetOCR(668, 996, 1249, 1064)

    if (current = "")
        return

    if (current = lastOCR) {

        if (stableStart = 0)
            stableStart := A_TickCount

        if ((A_TickCount - stableStart) >= 8000
            && (A_TickCount - lastPauseTime) > 3000) {

            lastPauseTime := A_TickCount
            PauseClicking()

            stableStart := 0
        }

    } else {
        lastOCR := current
        stableStart := A_TickCount
    }
}

Upgrades() {
WaitIfPaused()
DisableAllTimers()
SetTimer(MainLoop, 10000)
SetTimer(CheckCrash, 10000)
    filePath := linkFile
    if !FileExist(filePath) {
        MsgBox "link.txt not found!"
        return
    }

    content := FileRead(filePath)

    upgradeType := ""
    ratioValue := ""

for line in StrSplit(content, "`n") {
    line := Trim(line)

    if InStr(line, "upgrade=")
        upgradeType := Trim(StrReplace(line, "upgrade="))

    if InStr(line, "ratio=")
        ratioValue := Trim(StrReplace(line, "ratio="))
}

if (upgradeType = "Coins") {
    WriteLog("Upgrade = Coins, going to Normal Maps code")
    NormalMaps()
    return
}

    color := PixelGetColor(1535, 217, "RGB")

    if (CheckColor(1535, 217, 0xD10000, 10)) {
        WriteLog("Closing Crate Menu")
        Click 1540, 229
    }

    Sleep 100
    color := PixelGetColor(747, 364, "RGB")

    if (!CheckColor(747, 364, 0x000000, 10)) {
        WriteLog("Opening Shop Menu")
        Click 64, 451
    }
    Sleep 200

    for line in StrSplit(content, "`n") {
        line := Trim(line)

        if InStr(line, "upgrade=")
            upgradeType := Trim(StrReplace(line, "upgrade="))

        if InStr(line, "ratio=")
            ratioValue := Trim(StrReplace(line, "ratio="))
    }

selectedRatio := ratioValue

if (upgradeType = "Ratio") {
    RatioUpgrade(selectedRatio)
}

else if (upgradeType != "") {
    NormalUpgrade(upgradeType)
} 
else {
    MsgBox "No upgrade type found!"
    return
}
    AfterUpgrade()
}

NormalUpgrade(type) {
WaitIfPaused()

    if (type = "Size") {
        WriteLog("Upgrading Size")
        Click 1503, 444
    }
    else if (type = "Walkspeed") {
        WriteLog("Upgrading Walkspeed")
        Click 1503, 658
    }
    else if (type = "Multiplier") {
        WriteLog("Upgrading Multiplier")
        Click 1503, 867
    }
    else if (type = "EatSpeed") {
        Click 1187, 362
        start := A_TickCount
        while (A_TickCount - start < 300) {
            Send "{WheelDown}"
        }
        Sleep 250
        WriteLog("Upgrading EatSpeed")
        Click 1503, 892 
    }
}

AfterUpgrade() {

    Sleep 2000

    if (CheckColor(67, 619, 0xFFFFFF, 10)) {
        NormalMaps()
        return
    }

    loop {
        WaitIfPaused()
        if (CheckColor(829, 390, 0xE1E3E9, 10)) {

            loop {
                WaitIfPaused()
                Click 1155, 392
                Sleep 100

                if (CheckColor(60, 708, 0x191A1B, 10)) {
                    NormalMaps()
                    return
                }
            }
        } 
        else {
            Sleep 2000
        }
    }
}

RatioUpgrade(ratio) {

    sizeText := GetOCR(1092, 435, 1282, 467)
    multiText := GetOCR(1100, 855, 1274, 885)

    sizeLevel := RegExReplace(sizeText, "[^0-9\.]")
    multiLevel := RegExReplace(multiText, "[^0-9\.]")

    size := Number(sizeLevel)
    multi := Number(multiLevel)
    ratioVal := Number(ratio)

    if (size = 0 || multi = 0 || ratioVal = 0) {
        return
    }

    expectedSize := ratioVal * multi
    tolerance := 0.2

    if (Abs(size - expectedSize) <= tolerance) {
        WriteLog("Ratio upgrading SIZE")
        Click 1503, 444
    }
    else if (size < expectedSize) {
        WriteLog("Ratio upgrading SIZE")
        Click 1503, 444
    }
    else {
        WriteLog("Ratio upgrading MULTIPLIER")
        Click 1503, 658
    }
}

NormalMaps() {
WaitIfPaused()
    Loop {
        WaitIfPaused()
        WriteLog("Closing Shop Menu")
        Click 1618, 229
        Sleep 300

        if (!CheckColor(1617, 214, 0xD10000, 10))
            break
    }
    
    color1 := PixelGetColor(343, 1031, "RGB")

    if (CheckColor(343, 1031, 0x3C8E26, 10)) {
        GoFullLogic()
    } else {
        GoEndLogic()
    }
}

global mode := ""


GoFullLogic() {
    global mode

    if (mode != "" && mode != "FULL")
        return

    mode := "FULL"
    
WriteLog("Size bar more than 10%, performing Autoclicking & Checkers")
StartClicking(20)

Loop {
    Sleep 100
    color1 := PixelGetColor(1471, 999, "RGB")

    if (CheckColor(1673, 1030, 0x3C8C26, 12)) {

    SetTimer StartOCR, 0
    SetTimer OCRChecker, 0
    StartClicking(150)

Loop {
    WaitIfPaused()

    if (CheckColor(1706, 1029, 0x3C8B26, 12)) {
        WriteLog("Max Size detected")
        break
    }

    Sleep 50
}

    StopClicking()
    Sleep 50
    GoEndLogic()
}
}
}

GoEndLogic() {

    if (CheckColor(281, 1028, 0x3C8F26, 10)) {
        Loop {
            WaitIfPaused()
            WriteLog("Selling")
            Click 215, 1000
            Sleep 100

            if (CheckColor(211, 1039, 0x181B1C, 10))
                break
        }
    }

    Loop {
        WaitIfPaused()
        WriteLog("Opening Normal Maps Menu")
        Click 65, 659
        Sleep 500

        if (CheckColor(826, 639, 0x181A1B, 10))
            break
    }

Loop {
    WaitIfPaused()
    if (CheckColor(20, 613, 0xF8F8F8, 10))
        break

    Loop 5 {
        WaitIfPaused()
        if (CheckColor(20, 613, 0xF8F8F8, 10))
            break 2
        WriteLog("Joining Normal Maps")
        Click 953, 727
        Sleep 1000
    }

    Sleep 3000
}

    Loop {
        WaitIfPaused()
        Sleep 200
        if (CheckColor(219, 1027, 0x191C1D, 10))
            break
    }

    Sleep 10000
    StartLogic()
    SetTimer(MainLoop, 10000)
    SetTimer(CheckCrash, 10000)
}

CheckCrash() {
WaitIfPaused()
    if (PixelGetColor(1072, 442, "RGB") = 0x393B3D) {
        WriteLog("Disconnect")
        ProcessClose("RobloxPlayerBeta.exe")
        Sleep 2000
        WriteLog("Not in private, rejoining")
        Rejoin()
    }
}


Rejoin() {
WaitIfPaused()
    global privateLink, Browser
    DisableAllTimers()
    SetTimer(MainLoop, 0)
    SetTimer(CheckCrash, 0)
    isRunning := false

if WinExist("ahk_exe RobloxPlayerBeta.exe") {
    WinClose("ahk_exe RobloxPlayerBeta.exe")
    if !WinWaitClose("ahk_exe RobloxPlayerBeta.exe", , 3) {
        WriteLog("Closing Roblox")
        ProcessClose("RobloxPlayerBeta.exe")
        Sleep 200
    }
}
    maxAttempts := 3
    success := false

    Loop maxAttempts {
        WaitIfPaused()
        attempt := A_Index
        WriteLog("Running Private link")
        RunBrowser(privateLink)

        if WinWait("ahk_exe RobloxPlayerBeta.exe", , 30) {
            success := true
            break
        }
        Sleep 2000
    }

    if !success {
        MsgBox("Invalid or failed Roblox link. Script will now exit.")
        ExitApp()
    }
    WriteLog("Closing Browser")
    CloseBrowser()
    Sleep 3500

    Loop {
        WaitIfPaused()
        style := WinGetStyle("ahk_exe RobloxPlayerBeta.exe")

        if (style & 0xC00000) {
            Send "{F11}"
            Sleep 1000
        } else {
            break
        }
    }
    Sleep 250
    Loop {
        WaitIfPaused()

        if (CheckColor(221, 1027, 0x191C1D, 10))
            break

        Sleep 500
    }

    Sleep 1000
    ToolTip()

    StartLogic()
    SetTimer(MainLoop, 10000)
    SetTimer(CheckCrash, 10000)
}


RunBrowser(link) {
    global Browser

    try {
        switch Browser {
            case "Google Chrome":
                Run('chrome.exe "' link '"')

            case "Microsoft Edge":
                Run('msedge.exe "' link '"')

            case "Mozilla Firefox":
                Run('firefox.exe "' link '"')

            case "Opera":
                Run('opera.exe "' link '"')

            case "Opera GX":
                Run('opera.exe "' link '"')

            case "Brave":
                Run('brave.exe "' link '"')

            case "Vivaldi":
                Run('vivaldi.exe "' link '"')
            case "360 Extreme Browser":
                 Run(link)

            default:
                Run(link)
        }
    } catch {
        Run(link)
    }
}

CloseBrowser() {
    global Browser

    switch Browser {
        case "Google Chrome":
            WinClose("ahk_exe chrome.exe")

        case "Microsoft Edge":
            WinClose("ahk_exe msedge.exe")

        case "Mozilla Firefox":
            WinClose("ahk_exe firefox.exe")

        case "Opera":
            WinClose("ahk_exe opera.exe")

        case "Opera GX":
            WinClose("ahk_exe opera.exe")

        case "Brave":
            WinClose("ahk_exe brave.exe")

        case "Vivaldi":
            WinClose("ahk_exe vivaldi.exe")
        case "360 Extreme Browser":
            WinClose "ahk_exe 360mlupdate.exe"
           
    }
}

DisableAllTimers() {

    StopClicking()
    SetTimer Sell, 0
    SetTimer CheckRGB, 0
    SetTimer OCRChecker, 0
}

GetCurrentResolution() {
    devmode := Buffer(156, 0)
    NumPut("UInt", 156, devmode, 36)                    
    DllCall("EnumDisplaySettingsA", "Ptr", 0, "UInt", -1, "Ptr", devmode.Ptr)
    width  := NumGet(devmode, 108, "UInt")  
    height := NumGet(devmode, 112, "UInt")  
    return width "|" height
}
SetResolution(w, h) {
    devmode := Buffer(156, 0)

   
    NumPut("UShort", 156, devmode, 36)

    DllCall("EnumDisplaySettingsA", "Ptr", 0, "UInt", -1, "Ptr", devmode.Ptr)

    NumPut("UInt", 0x5C0000, devmode, 40)
    NumPut("UInt", w, devmode, 108)
    NumPut("UInt", h, devmode, 112)

    result := DllCall("ChangeDisplaySettingsA", "Ptr", devmode.Ptr, "UInt", 0)

    return result
}
GetScaling() {
    try {
        RegRead("HKEY_CURRENT_USER\Control Panel\Desktop", "LogPixels")
    } catch {
        return 96
    }
}

SetScaling(dpiValue) {
    try {
        RegWrite(dpiValue, "REG_DWORD", "HKEY_CURRENT_USER\Control Panel\Desktop", "LogPixels")
        RegWrite(1, "REG_DWORD", "HKEY_CURRENT_USER\Control Panel\Desktop", "Win8DpiScaling")
        DllCall("user32\SystemParametersInfo", "UInt", 0x009F, "UInt", 0, "Ptr", 0, "UInt", 2) 
    }
}

RestoreDisplay() {
    global originalWidth, originalHeight, originalDPI
    if (originalWidth != "")
        SetResolution(originalWidth, originalHeight)
    if (originalDPI != "")
        SetScaling(originalDPI)
}

HandleExit(*) {

    WriteLog("Macro exited")
    StopClicking()
    RestoreDisplay()
    ExitApp()
}

UpgradeChanged(*) {
    global UpgradeSystem, MyGui

    UpgradeSystem := MyGui["UpgradeSystem"].Text

    if (UpgradeSystem = "Ratio") {
        MyGui["RatioLabel"].Visible := true
        MyGui["RatioValue"].Visible := true
        MyGui["RatioMinus"].Visible := true
        MyGui["RatioPlus"].Visible := true
    } else {
        MyGui["RatioLabel"].Visible := false
        MyGui["RatioValue"].Visible := false
        MyGui["RatioMinus"].Visible := false
        MyGui["RatioPlus"].Visible := false
    }

    SaveAll()
}

RatioUp(*) {
    global RatioValue, MyGui
    if (RatioValue < 6) {
        RatioValue += 0.5
        MyGui["RatioValue"].Value := RatioValue
        SaveAll()
    }
}

RatioDown(*) {
    global RatioValue, MyGui
    if (RatioValue > 4) {
        RatioValue -= 0.5
        MyGui["RatioValue"].Value := RatioValue
        SaveAll()
    }
}
HandlePause(*) {
    global isPaused, lastPauseToggle

    if (A_TickCount - lastPauseToggle < 250)
        return

    lastPauseToggle := A_TickCount
    isPaused := !isPaused

    if (isPaused) {
        FileAppend "", pauseFile
        WriteLog("Pausing")
        ToolTip("⏸ Paused")
    } else {
        FileDelete pauseFile
        WriteLog("Resuming")
        ToolTip("▶ Resumed")
    }

    SetTimer(() => ToolTip(), -1000)
}
WaitIfPaused() {
    global isPaused
    while (isPaused)
        Sleep 100
}